import React from "react";

function CommingSoon() {
  return (
    <div className="bg-gradient-to-r from-[#76b2b9] to-[#0dd3d374] flex  flex-1 h-screen w-screen justify-center items-center ">
      <p className="text-[100px] font-bold text-[#fff]  ">ThankYou</p>
    </div>
  );
}

export default CommingSoon;
